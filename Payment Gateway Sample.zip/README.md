# node-express-vercel
Hosting express node project on vercel

### Video
> https://youtu.be/vCuf62T2snY

### Deployed on
> https://node-express-vercel-rose.vercel.app/home
